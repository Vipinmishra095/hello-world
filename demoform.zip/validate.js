function validate(id = null) {
  if (id) {
    $(".error", formElement).remove();

    var formElement = $("#" + id);
    $(".required", formElement).each(function (i, e) {
      if ($(e).val().trim() == "") {
        $(e).after('<p class="fr-error error">This field is required</p>');
      }
    });

    $(".number", formElement).each(function (i, e) {
      if ($(e).next(".error").length == 0) {
        $(e).next(".error").remove();
        if (isNaN($(e).val()) == true) {
          $(e).after('<p class="fr-error error">Only numbers allowed</p>');
        }
      }
    });

    $(".email", formElement).each(function (i, e) {
      if ($(e).next(".error").length == 0) {
        $(e).next(".error").remove();
        if (/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test($(e).val()) == false) {
          $(e).after('<p class="fr-error error">Invalid email</p>');
        }
      }
    });

    if ($(".error", formElement).length) {
      return false;
    } else {
      return false;
    }
  } else {
    console.error("Form id param required");
  }
}
$(document).ready(function () {

  $(".required").on("keyup change", function () {

    if ($(this).next(".error").length) {
      $(this).next(".error").remove();
    }
    if ($(this).val().trim() == "") {
      $(this).after('<p class="fr-error error">This field is required</p>');
    }
  });

  // $(".required").keyup(function () {
  //   if ($(this).next(".error").length) {
  //     $(this).next(".error").remove();
  //   }
  //   if ($(this).val().trim() == "") {
  //     $(this).after('<p class="fr-error error">This field is required</p>');
  //   }
  // });
  $(".number").keyup(function () {
    if ($(this).val().trim() != "") {

      if ($(this).next(".error").length) {
        $(this).next(".error").remove();
      }
      if (isNaN($(this).val()) == true) {
        $(this).after('<p class="fr-error error">Only numbers allowed</p>');
      }
    }
  });

  $(".email").keyup(function () {
    if ($(this).val().trim() != "") {

      if ($(this).next(".error").length) {
        $(this).next(".error").remove();
      }
      console.log(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test($(this).val()));
      if (/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test($(this).val()) == false) {
        $(this).after('<p class="fr-error error">Invalid email</p>');
      }
    }
  });

});